<?php
class productdbTranslationRow extends xPDOSimpleObject {}