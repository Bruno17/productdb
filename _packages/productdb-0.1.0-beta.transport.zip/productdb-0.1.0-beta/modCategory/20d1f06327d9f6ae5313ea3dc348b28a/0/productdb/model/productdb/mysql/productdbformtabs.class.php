<?php
require_once (dirname(__DIR__) . '/productdbformtabs.class.php');
class productdbFormtabs_mysql extends productdbFormtabs {}