<?php
require_once (dirname(__DIR__) . '/productdbrow.class.php');
class productdbRow_mysql extends productdbRow {}