<?php
require_once (dirname(__DIR__) . '/productdbformtab.class.php');
class productdbFormtab_mysql extends productdbFormtab {}