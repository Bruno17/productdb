<?php
require_once (dirname(__DIR__) . '/productdbtranslationrow.class.php');
class productdbTranslationRow_mysql extends productdbTranslationRow {}