<?php
class productdbLang extends xPDOSimpleObject {}