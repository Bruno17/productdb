<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'productdb-0.1.0-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd303dd22bf6c5d1732d31e6cb505d4a6',
      'native_key' => 'productdb',
      'filename' => 'modNamespace/bbbd3f6153a5102011cb21509df2b694.vehicle',
      'namespace' => 'productdb',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '74d51d29f7b98b6094ddd459591ff905',
      'native_key' => 1,
      'filename' => 'modCategory/20d1f06327d9f6ae5313ea3dc348b28a.vehicle',
      'namespace' => 'productdb',
    ),
  ),
);