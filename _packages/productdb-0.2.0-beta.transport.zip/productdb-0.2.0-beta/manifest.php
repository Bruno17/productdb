<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'productdb-0.2.0-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd5632475d07f434f7e1ae5402f9a0aa3',
      'native_key' => 'productdb',
      'filename' => 'modNamespace/f2b4b0e5a4e3eb7c168d6919669eae9f.vehicle',
      'namespace' => 'productdb',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd079379c2fcac68b9f893dd21208cdf2',
      'native_key' => 1,
      'filename' => 'modCategory/3dba218e7899edfab52b4ea532df6d9f.vehicle',
      'namespace' => 'productdb',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e1874c0b92897963ff38dab30f891a77',
      'native_key' => 'Product DB',
      'filename' => 'modMenu/eaf4f6cfa7b4e1f685e064585252ff6d.vehicle',
      'namespace' => 'productdb',
    ),
  ),
);