<?php
class productdbFlatRow extends xPDOSimpleObject {}