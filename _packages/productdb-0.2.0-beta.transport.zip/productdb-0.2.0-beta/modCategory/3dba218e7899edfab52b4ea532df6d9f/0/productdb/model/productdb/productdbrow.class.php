<?php
class productdbRow extends xPDOSimpleObject {}