<?php
require_once (dirname(__DIR__) . '/productdbflatrow.class.php');
class productdbFlatRow_mysql extends productdbFlatRow {}