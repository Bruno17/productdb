<?php
class productdbFormtabs extends xPDOSimpleObject {}