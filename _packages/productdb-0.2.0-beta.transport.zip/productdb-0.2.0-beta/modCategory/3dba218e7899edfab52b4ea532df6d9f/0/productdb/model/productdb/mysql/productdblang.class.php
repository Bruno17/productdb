<?php
require_once (dirname(__DIR__) . '/productdblang.class.php');
class productdbLang_mysql extends productdbLang {}