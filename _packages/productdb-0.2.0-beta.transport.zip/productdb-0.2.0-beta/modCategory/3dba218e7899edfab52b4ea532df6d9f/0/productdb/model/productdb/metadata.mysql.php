<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'productdbRow',
    1 => 'productdbFlatRow',
    2 => 'productdbTranslationRow',
    3 => 'productdbLang',
    4 => 'productdbFormtabs',
  ),
);