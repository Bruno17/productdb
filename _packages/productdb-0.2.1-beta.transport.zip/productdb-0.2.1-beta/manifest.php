<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'productdb-0.2.1-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c993d1d2ebee96874461206380f27796',
      'native_key' => 'productdb',
      'filename' => 'modNamespace/57958a539fb8f31398e11c4b1306c0a6.vehicle',
      'namespace' => 'productdb',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '84a9944d48cb88dfc2fa6fd9bbe68667',
      'native_key' => 1,
      'filename' => 'modCategory/ce8bd2ea3a7f7b12f3001373fb35edc1.vehicle',
      'namespace' => 'productdb',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cd788ce28e124a7fedcd3196bc480cc9',
      'native_key' => 'Product DB',
      'filename' => 'modMenu/7cd0a68e7d7039449a6e7054efebbf18.vehicle',
      'namespace' => 'productdb',
    ),
  ),
);