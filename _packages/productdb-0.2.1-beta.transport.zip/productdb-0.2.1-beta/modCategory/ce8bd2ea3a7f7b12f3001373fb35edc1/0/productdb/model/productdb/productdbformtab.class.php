<?php
class productdbFormtab extends xPDOSimpleObject {}